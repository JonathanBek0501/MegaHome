<template>
    <footer class="text-center text-white bg-brand py-4">
        © megahome.uz — Все права защищены.
    </footer>
</template>