<template>
    <div class="max-w-7xl mx-auto py-10 px-4 sm:px-6">
        <h2 class="text-4xl font-bold pb-5">
            Categories
        </h2>
        
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 grid-rows-[110px_110px] gap-2">
            <div class="relative group overflow-hidden lg:row-span-2 flex items-center gap-5 lg:block rounded bg-yellow-500 hover:shadow-brand transition-all ease-in-out p-5">
                <img src="/dishes.svg" alt="dishes" class="hidden sm:block w-16 lg:w-32">

                <div>
                    <h3 class="text-white font-medium text-lg">
                        Daxshat idishlar
                    </h3>
                    <span class="text-gray-300">
                        345 400na
                    </span>
                </div>

                <div class="translate-y-full group-hover:translate-y-0 transition-all ease-in-out absolute inset-0 w-full h-full flex flex-col gap-1 items-center justify-center bg-black/50">
                    <a href="#" class="text-white">
                        items 1
                    </a>
                    <a href="#" class="text-white">
                        items 1
                    </a>
                    <a href="#" class="text-white">
                        items 1
                    </a>
                </div>
            </div>
            <a href="/products" class="flex items-center gap-5 rounded bg-red-400 hover:shadow-brand transition-all ease-in-out p-5">
                <img src="/dishes.svg" alt="dishes" class="hidden sm:block w-16">

                <div>
                    <h3 class="text-white font-medium text-lg">
                        Offis va uy uchun kreslolar
                    </h3>
                    <span class="text-gray-300">
                        345 dona
                    </span>
                </div>
            </a>
            <a href="/products" class="flex items-center gap-5 rounded bg-red-400 hover:shadow-brand transition-all ease-in-out p-5">
                <img src="/dishes.svg" alt="dishes" class="hidden sm:block w-16">

                <div>
                    <h3 class="text-white font-medium text-lg">
                        Seyflar
                    </h3>
                    <span class="text-gray-300">
                        345 dona
                    </span>
                </div>
            </a>
            <div class="relative group overflow-hidden lg:row-span-2 flex items-center gap-5 lg:block rounded bg-yellow-500 hover:shadow-brand transition-all ease-in-out p-5">
                <img src="/dishes.svg" alt="dishes" class="hidden sm:block w-16 lg:w-32">

                <div>
                    <h3 class="text-white font-medium text-lg">
                        Daxshat idishlar
                    </h3>
                    <span class="text-gray-300">
                        345 400na
                    </span>
                </div>

                <div class="translate-y-full group-hover:translate-y-0 transition-all ease-in-out duration-200 absolute inset-0 w-full h-full flex flex-col gap-1 items-center justify-center bg-black/50">
                    <a href="#" class="text-white">
                        items 1
                    </a>
                    <a href="#" class="text-white">
                        items 1
                    </a>
                    <a href="#" class="text-white">
                        items 1
                    </a>
                </div>
            </div>
            <a href="/products" class="flex items-center gap-5 rounded bg-red-400 hover:shadow-brand transition-all ease-in-out p-5">
                <img src="/dishes.svg" alt="dishes" class="hidden sm:block w-16">

                <div>
                    <h3 class="text-white font-medium text-lg">
                        Chemodan
                    </h3>
                    <span class="text-gray-300">
                        345 dona
                    </span>
                </div>
            </a>
            <a href="/products" class="flex items-center gap-5 rounded bg-red-400 hover:shadow-brand transition-all ease-in-out p-5">
                <img src="/dishes.svg" alt="dishes" class="hidden sm:block w-16">

                <div>
                    <h3 class="text-white font-medium text-lg">
                        Daxshat idishlar
                    </h3>
                    <span class="text-gray-300">
                        345 dona
                    </span>
                </div>
            </a>
        </div>
    </div>
</template>