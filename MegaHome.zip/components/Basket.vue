<template>
    <div class="rounded-full bg-red-500 size-20">
        
    </div>
</template>