<template>
    <div class="flex gap-2 rounded w-full bg-gray-200 px-4">
        <a href="/" class="text-sm py-1">
            Asosiy sahifa
        </a>
        <span class="text-gray-400">
            /
        </span>
        <a href="/" class="text-sm py-1">
            Best sellers
        </a>
    </div>
</template>