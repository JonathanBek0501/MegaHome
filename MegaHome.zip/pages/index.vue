<template>
    <div>
        <PageHomeHero />
        <PageHomeBestSellers />
        <PageHomePopulars />
    </div>
</template>