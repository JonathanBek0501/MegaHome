<template>
    <div class="max-w-7xl mx-auto px-4 sm:px-6">
        <TheBreadcrumbs />

        <div class="max-w-5xl mx-auto flex items-center gap-20 py-6">
            <div class="max-w-md w-full h-full rounded-xl overflow-hidden">
                <img class="w-full h-full object-cover" src="/bestSellers/08DLX.jpg" alt="">
            </div>

            <div>
                <h2 class="sm:text-2xl font-semibold">
                    Kreslo 205 lorem20
                </h2>
                <p class="text-lg py-8">
                    DOMTIME zamonaviy ko'rinishdagi kreslo
                </p>
                <div>
                    <div class="grid grid-cols-[200px_1fr]">
                        <h3 class="font-bold">
                            Hajmlari:
                        </h3>
    
                        <p class="text-gray-400">
                            70x280x140mm
                        </p>
                    </div>
                </div>                
            </div>
        </div>
    </div>
</template>